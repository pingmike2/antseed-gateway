#!/usr/bin/env bash
# 在已装好 antseed-gateway 的机器上执行:替换网关脚本、收紧路由、移除自动换身份
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "请用 root 运行"; exit 1; }
SRC="${1:-./antseed-free-filter.py}"
[ -f "$SRC" ] || { echo "找不到 $SRC"; exit 1; }

install -m 755 "$SRC" /usr/local/bin/antseed-free-filter.py

# 仅免费:最高价设 0,避免被路由到付费 peer 吃 402
CFG=/root/.antseed/config.json
if [ -f "$CFG" ] && grep -q '"FREE_ONLY=1"' /etc/systemd/system/antseed-gateway.service; then
  python3 - "$CFG" <<'PY'
import json,sys
p=sys.argv[1]; c=json.load(open(p))
r=c.setdefault("buyer",{}).setdefault("routingPreferences",{})
r["preferFreePeers"]=True
r["maxInputUsdPerMillion"]=0
json.dump(c,open(p,"w"),indent=2)
PY
fi

# 移除 402 自动换身份
rm -f /usr/local/bin/antseed-rotate-identity.sh /tmp/antseed-rotate.lock

# 可调参数写进 drop-in,不改原 unit
mkdir -p /etc/systemd/system/antseed-gateway.service.d
cat > /etc/systemd/system/antseed-gateway.service.d/tuning.conf <<'CONF'
[Service]
Environment="PROBE_INTERVAL=300"
Environment="PROBE_TIMEOUT=45"
Environment="FAIL_THRESHOLD=2"
Environment="BLACKLIST_SECONDS=900"
Environment="AUTO_FALLBACK=1"
Environment="MAX_ATTEMPTS=3"
Environment="FALLBACK_ORDER=deepseek-v4-flash,glm-5.3-flash,openai-gpt-oss-120b"
CONF

systemctl daemon-reload
systemctl restart antseed-buyer.service
sleep 8
systemctl restart antseed-gateway.service
echo "完成。约 1 分钟后看健康状态: curl -s http://127.0.0.1:8377/health"
